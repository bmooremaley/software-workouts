function [] = startup()
  addpath /ocean/rich/home/matlab/gsw3
  addpath /ocean/rich/home/matlab/gsw3/html
  addpath /ocean/rich/home/matlab/gsw3/library
  addpath /ocean/rich/home/matlab/gsw3/thermodynamics_from_t
  addpath /ocean/rich/home/matlab/gsw3/pdf
