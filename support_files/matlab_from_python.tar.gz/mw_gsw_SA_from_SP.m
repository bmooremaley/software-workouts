function [] = mw_gsw_SA_from_SP(filename, SP, p, long, lat)
  startup()
  y = gsw_SA_from_SP(SP, p, long, lat)
  dlmwrite(filename, y, ',')
