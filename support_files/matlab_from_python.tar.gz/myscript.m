function [y] = myscript(x, filename)
  y = sin(x);
  dlmwrite(filename, y, ' ')
end



