import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt('summary.dat')
plt.plot(data[:, 1], data[:, 2], 'o')
plt.xlabel("Month")
plt.ylabel("Amount")
plt.savefig('figure3.eps')