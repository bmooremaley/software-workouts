# This script plots a submarine canyon and particle trajectories 
# using the mlab module of mayavi. 
#
# You need a GRID NC FILE that you can get form:
# https://www.eoas.ubc.ca/~kramosmu/grid_few_vars.nc
#
# and the TRAJECTORIES FILE that you can get from:
# https://www.eoas.ubc.ca/~kramosmu/ariane_trajectories_qualitative.nc
#

from math import *

from mayavi import mlab

from netCDF4 import Dataset

import numpy as np

# Bathymetry input
grid=Dataset('PATH TO GRID NC FILE')
xc = grid.variables['XC'][:,:] # x coords tracer cells
yc = grid.variables['YC'][:,:] # y coords tracer cells
bathy = grid.variables['depths'][:,:]



# Particle trajectories
trajFile = Dataset('PATH TO TRAJECTORIES NC FILE','r');

f_lont = trajFile.variables['traj_lon']
f_latt = trajFile.variables['traj_lat']
f_dept = trajFile.variables['traj_depth']

npart = len(f_lont[1,:])
partRange = np.arange(npart)



# mayavi figure
mlab.figure(size=(10, 10), bgcolor=(0.16, 0.28, 0.46))

surf = mlab.mesh(xc,yc,-bathy*30.0, 
		 color=(250.0/255,235.0/255,215.0/255),
		 scale_factor=0.1,
		 ) 

for nn in partRange:
  trajectory  = mlab.plot3d(f_lont[:34,nn], f_latt[:34,nn], f_dept[:34,nn]*30.0, f_dept[:34,nn], 
			    colormap='RdYlGn',tube_radius=None,
			    )
 
mlab.colorbar(trajectory, title='Depth', orientation='vertical')

mlab.show()
