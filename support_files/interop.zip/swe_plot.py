from __future__ import division

from datetime import date
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio

def addstationtoplot(ax, mat):
    # Read Dates
    year, month, day = mat['aspout'][:,1], mat['aspout'][:,2], mat['aspout'][:,3]

    # Put dates in format needed
    dateofyear = []
    for point in range(day.shape[0]):
        dateofyear.append(date(2000, int(month[point]), int(day[point])))

    SWE, flag = mat['aspout'][:,4], mat['aspout'][:,5]
    mask = (flag < 2) 

    # Plot masked arrays
    ax.plot_date(np.asarray(dateofyear)[mask], SWE[mask], 'o')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))

def swe_plot():
    '''Plot snow water equivalent for 3 stations as an annual cycle'''

    # set up figure
    fig, ax = plt.subplots(3,figsize=(5,10))
    ax[0].set_title('Annual Snow Water Equivalent at 3 Stations')

    # plot for each station
    for station, filename in enumerate(('1A01P','1A02P','1A03P')):
        mat = sio.loadmat(filename+'.mat')
        addstationtoplot(ax[station], mat)
        ax[station].annotate(filename, (0.8,0.8), xycoords='axes fraction')

    # format dates and save the figure
    fig.autofmt_xdate()
    fig.savefig('swe.png')

if __name__ == '__main__':
    swe_plot()
