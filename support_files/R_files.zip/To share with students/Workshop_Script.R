###################################
#####
#####   What is R? workshoop
#####  
###################################


#SCRIPT DESCRIPTION: sCRIPT MADE TO INTRODUCE R software to brand new users
#By:Laura Morillas
#DATE: Nov 26, 2015


######################
# Objects and Vectors:
######################

#Objects:
x<-3
y<-'Salmonella'

class(x)
class(y)


fecha<-"2015-03-25 00:00:00"
class(fecha)
as.Date(fecha)
fecha<-as.Date(fecha)
class(fecha)


#Vectors:
obs<-c(1,2,3,4,5,6)
y1<-c(1:6)
double_obs<-2*obs

b<-rep(5,6)  #rep 
a<-rep("falso",5)
y1[3]

wind_speed<-seq(from=12, to=2, by=-2)

#Exercise 1: how to create a new variable for our dataframe called wind speed and 
# with descending values from 4 to 1 m/s descending in regular steps??

wind_speed<-seq(from=4, to=1, by=-((4-1)/(nrow(data)-1)))

class(b) #there are interger,numeric,factor and Date
class(a)

is.factor(obs)
is.numeric(obs)

as.factor(obs)
as.numeric(obs)

length(a)
length(y)

#Basic functions to explore your data:
sum(obs)
mean(obs)
sd(obs)
min(obs)
max(obs)
range(obs)


#######################
# Creating a dataframe: 
######################
data<-as.data.frame(obs)
data
dim(data)
names(data)
data$obs

data$temperature<-rep(20,nrow(data))
data$temperature
data
dim(data)
names(data)
nrow(data)
ncol(data)

wind_speed

#How adding new variables (or columns) to your dataframe:
#Exercise 2:Check the dimensions of the previous vector "wind speed' and add it to our data dataframe 
# if dimensions match our dataset. 
#data$wind_speed<-wind_speed

#Add new variables in a diferent way:

data2<-cbind(data,wind_speed)
data2
dim(data2)
names(data2)


#How adding new observations (or rows) to your dataframe:
new_row<-c(7,21,1.2,0)

data2<-rbind(data2,new_row)
dim(data2)
data2

names(data2)

#Dealing with dataframes by indexes:

#how to remove variables form a dataset:
data2<-data2[,1:3]
data2
dim(data2)

#how to remove the last row we added:
data2<-data2[1:6,]
data2
dim(data2)

#Exercise 3:Double temperature in our dataframe data2 (two options, using indexes or not)
data2$temperature<-2*data2$temperature
data2$temperature<-2*data2[,2]

####################################
# Importing a preexisting database
####################################

#Importing .csv files:
dataset<-read.csv( "~/Desktop/R beginers workshop/DATASET.csv",sep=",",header=TRUE,dec=".")
head(dataset)
dim(dataset)
names(dataset)

#Importing .txt files:
dataset_txt<-read.table( "~/Desktop/R beginers workshop/DATASET.txt",sep="\t",header=TRUE,dec=".",skip=2) 
head(dataset_txt)
names(dataset_txt)<-names(dataset)

#Exercise 4:
#Estimate the mean and the standard deviation of the Air_temperature and wind_speed:
mean(dataset$Air_temperature)
sd(dataset$Air_temperature)

#Dealing with NA
mean(dataset$wind_speed,na.rm=T)
sd(dataset$Air_temperature,na.rm=T)

is.na(dataset$wind_speed)
dataset[is.na(dataset$wind_speed),]
dataset[is.na(dataset$wind_speed)==FALSE,]
dataset[is.na(dataset$wind_speed)==FALSE,8]

# Creating new variables based on previous variables:
dataset$variable<- dataset$PAR- dataset$Net_Radiation
dataset$Ta_10m<- 0.8*dataset$Air_temperature/100)*0.75

#####################
# Conditions and loops
#####################
mean_NR<-mean(dataset$Net_Radiation)
dataset$High_NR<-ifelse(dataset$Net_Radiation>mean_NR,1,0) #This function is very handy to avoid loops
#nested ifelse statements:
dataset$NR_levels<-ifelse(dataset$Net_Radiation>mean_NR,"higer",ifelse(dataset$Net_Radiation==mean_NR,'equal','lower'))
dataset$Ta_10m<-0.85*dataset$Air_temperature - 1.1

#LOOPS:

#IF FOR MORE THAN 2 CONDITIONS:
for (i in 1:nrow(dataset)){
  
  if(dataset$Net_Radiation[i]>mean_NR ) {dataset$NR_levels[i]<-'high'}
  if(dataset$Net_Radiation[i]==mean_NR) {dataset$NR_levels[i]<-'equal'}
  if(dataset$Net_Radiation[i]<mean_NR)  {dataset$NR_levels[i]<-'lower'}
} 
  
#IF ELSE FOR 2 CONDITIONS:  
for (i in 1:nrow(dataset)){
  if(dataset$Net_Radiation[i]==max(dataset$Net_Radiation) ) {
    
    dataset$NR_max_locator[i]<-'max'

    }else{
    dataset$NR_max_locator[i]<-0
    }
}
 

#Exercise 5: Build a loop to generate a new variable (named total rain) that will be the total rain for the whole day when NR_MAX_LOCATOR='MAX', and 0 in all the other cases 
for (i in 1:nrow(dataset)){
  if(dataset$NR_max_locator[i]=='max' ) {
    
    dataset$total_rain[i]<-sum(dataset$Rain)
    
  }else{
    dataset$total_rain[i]<-0
  }
}
dataset

#########################
#Installing R packages
##########################
#matrixStats package (includes handy basic functions as  rowSds() and rowMeans())
install.packages('matrixStats')
library('matrixStats')

#It is very common that you need to average several columns of your dataset (i.e several sensors (replicates) measuring the same)
dataset
anyMissing(dataset) # anyMissing is a function of MatrixStats package


######################
#BASIC PLOTTING
#####################

plot(dataset$Air_temperature)        
plot(dataset$Air_temperature,type='l')   #type 
plot(dataset$hours,dataset$Air_temperature,type='l')  #(x,y plot)
plot(dataset$hours,dataset$Air_temperature,type='b')  #type='b'
plot(dataset$RECORD,dataset$Air_temperature,type='l') 
plot(dataset$RECORD,dataset$Air_temperature,type='l',ylab='Air temperature (Celsius degrees)',xlab='Record')  #ylab, xlab
plot(dataset$RECORD,dataset$Air_temperature,type='l',ylab='Air temperature (Celsius degrees)',xlab='Record',ylim=c(0,50)) #ylim
lines(dataset$RECORD,dataset$Ta_10m,col='red') #lines
points(dataset$RECORD,dataset$Tair_mean,col='green') #points
?par

#Multipanel plots
par(mfrow=c(2,2)) 
plot(dataset$RECORD,dataset$Air_temperature,type='l',ylab='Air temperature (Celsius degrees)',xlab='Record')  #ylab, xlab
plot(dataset$RECORD,dataset$Ta_10m,type='l',ylab='Air temperature at 10 m (Celsius degrees)',xlab='Record',col='red')  #ylab, xlab
plot(dataset$Air_temperature,dataset$Ta_10m,xlab='Air temperature (Celsius degrees)',ylab='Air temperature at 10 m (Celsius degrees)',xlim=c(10,32),ylim=c(10,32))
abline(0,1,lty=2,col='grey')
abline(lm(dataset$Ta_10m ~ dataset$Air_temperature))  #lm(y ~ x)
plot(dataset$Air_temperature-dataset$Ta_10m,xlab='Record',ylab='Air temperature Difference (Celsius degrees)',ylim=c(0,max(dataset$Air_temperature-dataset$Ta_10m)))
Ta_diff<-dataset$Air_temperature-dataset$Ta_10m
abline(h=min(Ta_diff),col='green')
abline(v=40,col='orange')


#######################
#BASICS lINEAR MODELS (not time most likely)
#######################
Tair_model<-lm(dataset$Air_temperature ~ dataset$Ta_10m)
Tair_model
summary(Tair_model)
