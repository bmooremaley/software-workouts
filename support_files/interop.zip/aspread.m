function aspread(filename)
    % This fuction loads automated snow pillow data from .csv files 
    % retrieved from BC River Forecast Centre 
    % (http://bcrfc.env.gov.bc.ca/data/asp/archive.htm)
    % into a flat table by station 
    % The data is matched with flag numbers from the obsflag array
    % then stored in variable 'aspout' and saved to a matfile.
    % The columns of aspout are:
    %   ASP station number
    %   Year
    %   Month
    %   Day
    %   Measured snow water equivalent (mm)
    %   Flag number (1=good, 2+=discard)

    % load supporting mat files and initialize
    matpath = './';
    %matpath = '../matfiles/';
    load([matpath 'aspstnflags.mat'],'aspstnID','aspstnnum','obsflag');
    [~,~,obsflagn] = unique(obsflag);

    % get file information
    datpath = './';
    %datpath = '../data/ASP/';
    csvfile = dir([datpath filename]);
    lc = length(csvfile);
    if lc < 1 
        error([datpath filename ': file not found'])
    end

    % loop through files if wild cards passed
    for j=1:lc
        filepathj = [datpath csvfile(j).name];
        aspstnIDj = csvfile(j).name(1:5);
        aspstnnumj = find(ismember(aspstnID,aspstnIDj,'rows'));

        %open file
        fid = fopen(filepathj);

        % read past header
        header = textscan(fid, '%s', 9, 'Delimiter','\n');

        % read pillow id, date, swe
        % all other fields not read 
        % (interpreted as a string s to prevent stopping on * codes in csv data fields)
        pf='%s %s %*s %*s %*s %*s %*s %*s %*s %*s %f %s %*s %*s';
        parms = textscan(fid, pf,'Delimiter',',');
        fclose(fid);

        % load date and swe into matrix
        ltrunc=1; % # blank lines to truncate at EOF
        datecell=parms{2}(1:length(parms{2})-ltrunc);
        aspjswe=parms{3}(1:length(parms{3})-ltrunc);
        %aspjswecode=parms{4}(1:length(parms{4})-ltrunc);

        ldate=length(datecell); 
        laspj=length(aspjswe);

        % find year and column
        aspdatechar=char(datecell);

        % try to get date
        try
            aspdatenum=datenum(aspdatechar);
        catch errdn
            error(['error in datenum for station ' aspstnID(j,:) ': ' errdn]);
        end

        % retrieve date parameters
        [aspyr,M,D,~,~,~]=datevec(aspdatenum);

        % load into output array
        try
            aspout=[repmat(aspstnnumj,laspj,1) aspyr M D aspjswe ...
                obsflagn(aspstnnum==aspstnnumj)];
        catch errout
            error(['error in assembling output for station ' aspstnID(j,:) ': ' errout]);
        end

        % save to matfile
        save([matpath aspstnID(aspstnnumj,:) '.mat'],'aspout')

        display(['station #' int2str(aspstnnumj) ' ' aspstnID(aspstnnumj,:) ...
            ' processed ' int2str(ldate) ' dates & ' int2str(laspj) ' measurements']);


    end

end






