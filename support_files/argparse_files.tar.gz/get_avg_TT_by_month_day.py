
def get_avg_TT_by_month_day(HOBO_df):
    '''
    Routine to extract the daily average temperature from HOBO-Logger Data.
    
    With the re-configured Data Frame, there are two ways we can extract the 
    daily-average TT values.
    
        1. Using traditional for-loops & Conditioning.
        2. Utilizing the 'groupby()' function in the Pandas library.
        
    This version of the routine calculates the daily averges using the
    traditional for-loop flow control, although this method may get a little
    messy and chunky.
    
    INPUTS:
    
        1. HOBO_data : - A dictionary of differing HOBO-Logger datasets.
                       - Dict can be of any length.
                       - To access a specific HOBO dataset, simply input the 
                         file name of that dataset as the key to the dictionary.
                       - The HOBO_data keys will be looped through and the data
                         will be reconfigured with the CONFIG_HOBO_DATA() function.
                       - Once reformatted, the 
    '''
    import pandas as pd
    import numpy as np
    
    ##  1. Definition to reorganize original data.frame 
    def config_HOBO_data(HOBO_df):
        '''
        Routine to re-organize original HOBO dataframe imported to 
        one that is organized by:
    
        1. DateTime
        2. Year
        3. Month number
        4. Day number
        5. Temperature
    
        By re-organizing the temperatue data to this format, it will 
        be easier to average all the temperature recordings for each day 
        of each month.
    
        Input:
            - 'HOBO_df': The original data frame of HOBO data, imported.
        '''
        import datetime
        import pandas as pd
    
        ##  > Parsing time Stamps from original HOBO data:
        yy, mm, dd = [], [], []  ##  year, month, day
        hh, mn, ss = [], [], []  ##  hour, minute, second
        gmt_time = ['Date Time']
        for gmt in gmt_time:
            if gmt in HOBO_df.columns.values:
                for time_stamp in pd.to_datetime(HOBO_df[gmt]):
                    yy.append(time_stamp.year)
                    mm.append(time_stamp.month)
                    dd.append(time_stamp.day)
                    hh.append(time_stamp.hour)
                    mn.append(time_stamp.minute)
                    ss.append(time_stamp.second)
                t = []
                for year, month, day, hour, minute, second in zip(yy, mm, dd, hh, mn, ss):
                    t.append(datetime.datetime(year, month, day, hour, minute, second))
        ##  > Organize a new dictionary of data fields to be included in newly 
        ##    configured data frame.
        data_fields = {
            'DateTime' : t, 
            'Year' : yy, 
            'Month' : mm, 
            'Day' : dd, 
            'Hour' : hh, 
            'Minute' : mn, 
            'Second' : ss, 
            'Temperature' : HOBO_df['Temp']
        }
        ##  > Creating newly configured data frame object:
        reconfig_hobo_df = pd.DataFrame(data_fields) 
        return reconfig_hobo_df
    ##
    ##  Using the 'groupby()' from Pandas and the lambda function, we can 
    ##  create a Pandas Series of the Daily Average Temperatures for each month and day:
    ##
    configured_hobo_df = config_HOBO_data(HOBO_df)
    daily_avg_TT_by_month_day = configured_hobo_df.groupby('Year').apply(lambda x: x.groupby('Month').apply(lambda x: x.groupby('Day').agg(np.mean)))
    ##
    ##  The above statement returns HOBO_daily_avg_TT_df as a 
    ##  Pandas Data Frame object with daily average temperature values by day and month.
    ##
    return daily_avg_TT_by_month_day