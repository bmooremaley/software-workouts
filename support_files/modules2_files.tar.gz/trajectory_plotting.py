# Copyright 2013-2016 Susan Allen and SWC-workout contributors
# and The University of British Columbia

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#    http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Functions to produce a plot of trajectories versus bathymetry"""

import cmocean
import matplotlib.pyplot as plt
import matplotlib.colors as mpl_colors
import matplotlib.colorbar as mpl_colorbar

import netCDF4 as nc
import numpy as np
import xarray as xr


def get_bathymetry(imin, imax, jmin, jmax):
    """Get a section of bathymetry from the ERDDAP server
    
    :arg int imin: lowest index in NW-SE direction
    
    :arg int imax: highest index in NW-SE direction
    
    :arg int jmin: lowest index in SW-NE direction
    
    :arg int jmax: highest index in SW-NE direction

    :returns: latitudes, longitudes and depth
    :rtype: 3-tuple
    """
    
    # make our slices
    i_slice = slice(imin, imax)
    j_slice = slice(jmin, jmax)

    # get the bathymetry
    grid = xr.open_dataset(
        'https://salishsea.eos.ubc.ca/erddap/griddap/ubcSSnBathymetry2V1')
    bathy = (grid.bathymetry.isel(gridY=i_slice, gridX=j_slice))
    lats = (grid.latitude.isel(gridY=i_slice, gridX=j_slice))
    lons = (grid.longitude.isel(gridY=i_slice, gridX=j_slice))
    
    return lats, lons, bathy


def get_trajectories(filename):
    """Get the trajectories

    :arg str filename: name of the trajectory file. File should be in
                       output format that Ariane produces

    :returns: trajectories
    """
    
    traj = np.loadtxt(filename, delimiter=' ')
    
    return traj


def bathy_map(lats, lons, bathy):
    """Make a bathymetry figure and axes
    
    :arg ndarray lats: latitude array
    
    :arg ndarray lons: longitude array

    :arg ndarray bathy: depths array

    returns: figure and axis objects
    """
    
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_axes([0.05, 0.1, 0.9, 0.9])
    mesh = ax.contourf(lons, lats, bathy, cmap=cmocean.cm.deep)
    fig.colorbar(mesh)
    ax.set_xlim((-123.5, -123.1))
    ax.set_ylim((49.05, 49.35))
    
    return fig, ax


def traj_map(fig, ax, traj):
    """Adds depth coloured trajectories to map

    :arg matplotlib.figure.Figure fig: the figure

    :arg matplotlib.axes.Axes ax: the figure axis

    :arg ndarray traj: the trajectories

    :returns: None
    """
    
    deep = -110
    shallow = -35
    ax1 = fig.add_axes([0.05, 0.00, 0.9, 0.05])

    for i in range(traj.shape[0]):
        scaled_z = (traj[i,3] -deep) / (shallow-deep)
        cmap = plt.cm.plasma
        color = cmap(scaled_z)
        ax.scatter(traj[i,1], traj[i,2], c=color)
    norm = mpl_colors.Normalize(vmin=deep, vmax=shallow)
    cb1 = mpl_colorbar.ColorbarBase(ax1, cmap=cmap,
                                norm=norm,
                                orientation='horizontal')
    cb1.set_label('Depth (m)')


def plot_outfall(ax, lats, lons, outx, outy):
    """Add outfall location to map

    :arg matplotlib.axes.Axes ax: the figure axis

    :arg ndarray lats: latitude array
    
    :arg ndarray lons: longitude array
    
    :arg int outx: the x coordinate of the outfall

    :arg int outy: the y coordinate of the outfall

    :returns: None
    """
    
    ax.plot(lons[outy, outx], lats[outy, outx], 'wo');
